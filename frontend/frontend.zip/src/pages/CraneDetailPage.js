import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  ArrowLeftIcon,
  BoltIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  LinkIcon,
  PlusIcon,
  ScaleIcon,
  TrashIcon,
  TruckIcon,
} from '@heroicons/react/24/outline';
import { StatusBadge, Spinner, EmptyState, ConfirmDialog } from '../components/common';
import api from '../utils/api';
import { format } from 'date-fns';

const AttachmentTable = ({ title, items, columns, emptyIcon, onDelete, isOpen, onToggle, pageSize = 5 }) => {
  const [page, setPage] = useState(1);

  useEffect(() => {
    setPage(prev => Math.min(prev, Math.max(1, Math.ceil(items.length / pageSize))));
  }, [items.length, pageSize]);

  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const paginatedItems = items.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="card mb-4 overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        className="w-full flex items-center justify-between gap-3 rounded-lg px-1 py-2 text-left transition-colors hover:bg-gray-50 dark:hover:bg-gray-700/40"
      >
        <div className="flex items-center gap-3">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200" aria-hidden="true">
            {emptyIcon}
          </span>
          <div>
            <p className="font-semibold text-gray-800 dark:text-white">{title} ({items.length})</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{isOpen ? 'Hide list' : 'Show list'}</p>
          </div>
        </div>
        <ChevronDownIcon className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        items.length === 0 ? (
          <div className="mt-3">
            <EmptyState message={`No ${title.toLowerCase()} assigned`} icon={emptyIcon} />
          </div>
        ) : (
          <div className="mt-3">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b dark:border-gray-700">
                    {columns.map(c => <th key={c.key} className="table-header">{c.label}</th>)}
                    <th className="table-header text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedItems.map((item, i) => (
                    <tr key={item._id || i} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                      {columns.map(c => (
                        <td key={c.key} className="table-cell">
                          {c.badge ? <StatusBadge status={item[c.key]} /> : (item[c.key] || '—')}
                        </td>
                      ))}
                      <td className="table-cell text-center">
                        <button
                          onClick={() => onDelete(item._id, item.itemName || item.boomCode || item.hookSerialNo || 'Item')}
                          title="Delete"
                          className="inline-flex items-center gap-1 px-2 py-1 text-xs rounded border border-red-200 dark:border-red-700 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors"
                        >
                          <TrashIcon className="w-3 h-3" /> Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3 flex-wrap">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Showing {Math.min((page - 1) * pageSize + 1, items.length)}-{Math.min(page * pageSize, items.length)} of {items.length}
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPage(prev => Math.max(1, prev - 1))}
                  disabled={page === 1}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeftIcon className="w-3.5 h-3.5" /> Prev
                </button>
                <span className="text-xs text-gray-500 dark:text-gray-400">Page {page} of {totalPages}</span>
                <button
                  type="button"
                  onClick={() => setPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={page === totalPages}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Next <ChevronRightIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )
      )}
    </div>
  );
};

export default function CraneDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const initialCrane = location.state?.crane || null;
  const [crane, setCrane] = useState(initialCrane);
  const [loading, setLoading] = useState(!initialCrane);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteType, setDeleteType] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [openSections, setOpenSections] = useState({
    counterweights: false,
    boomSections: false,
    hooks: false,
  });

  useEffect(() => {
    if (initialCrane) {
      setCrane(initialCrane);
      setLoading(false);
      return;
    }
    api.get(`/cranes/${id}`)
      .then(r => setCrane(r.data.data))
      .catch(() => { toast.error('Crane not found'); navigate('/cranes'); })
      .finally(() => setLoading(false));
  }, [id, navigate, initialCrane]);

  const handleDeleteAttachment = async (itemId, itemName, type) => {
    setDeleteTarget({ itemId, itemName });
    setDeleteType(type);
  };

  const toggleSection = section => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const confirmDelete = async () => {
    if (!deleteTarget || !deleteType || deleting) return;
    
    setDeleting(true);
    try {
      const endpoints = {
        counterweight: '/counterweights',
        boom: '/boom-sections',
        hook: '/hooks'
      };
      
      const url = `${endpoints[deleteType]}/${deleteTarget.itemId}`;
      console.log(`🗑️ Deleting ${deleteType} at ${url}`);
      
      const deleteResponse = await api.delete(url);
      console.log('Delete response:', deleteResponse);
      
      toast.success(`${deleteTarget.itemName} deleted permanently`);
      
      // Refresh crane data
      console.log(`🔄 Refreshing crane data for ID: ${id}`);
      const { data } = await api.get(`/cranes/${id}`);
      console.log('Updated crane data:', data.data);
      
      setCrane(data.data);
      setDeleteTarget(null);
      setDeleteType(null);
    } catch (err) {
      console.error('Delete error:', err);
      toast.error(err.response?.data?.message || 'Failed to delete');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;
  if (!crane) return null;

  const infoFields = [
    { label: 'Equipment No.', value: crane.equipmentNo },
    { label: 'Sarens No.', value: crane.sarensNo },
    { label: 'Equipment Type', value: crane.equipmentType },
    { label: 'Model', value: crane.craneModel },
    { label: 'Year', value: crane.yearModel },
    { label: 'Weight', value: crane.capacity },
    { label: 'Plate No.', value: crane.plateNo },
    { label: 'Serial No.', value: crane.serialNumber },
    { label: 'Manufacturer', value: crane.manufacturer },
    { label: 'Location', value: crane.location },
    { label: 'Client', value: crane.client },
    { label: 'Division', value: crane.division },
    { label: 'Supervisor', value: crane.supervisor },
    { label: 'Max Config', value: crane.maxConfiguration },
    { label: 'Working Config', value: crane.workingConfiguration },
    { label: 'Starting Date', value: crane.startingDate ? format(new Date(crane.startingDate), 'MMM d, yyyy') : null },
    { label: 'Release Date', value: crane.releaseDate ? format(new Date(crane.releaseDate), 'MMM d, yyyy') : null },
  ];

  return (
    <div>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate('/cranes')} className="btn-secondary flex items-center gap-2">
          <ArrowLeftIcon className="w-4 h-4" /> Back
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="inline-flex items-center gap-2 rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1">
              <TruckIcon className="w-4 h-4 text-slate-700 dark:text-slate-200" />
              <h1 className="text-2xl font-black text-gray-900 dark:text-white font-mono" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.08)' }}>{crane.equipmentNo}</h1>
            </div>
            <StatusBadge status={crane.status} />
          </div>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{crane.equipmentType} — {crane.craneModel}</p>
        </div>
        <Link to="/transactions/create" state={{ crane: crane.equipmentNo, craneId: crane._id }}
          className="btn-primary flex items-center gap-2">
          <PlusIcon className="w-4 h-4" /> Create Transaction
        </Link>
      </div>

      {/* Crane Info */}
      <div className="card mb-4">
        <h2 className="font-semibold text-gray-800 dark:text-white mb-4">Crane Information</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {infoFields.filter(f => f.value).map(f => (
            <div key={f.label}>
              <p className="text-xs font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wide">{f.label}</p>
              <p className="text-sm font-medium text-gray-800 dark:text-gray-200 mt-0.5">{f.value}</p>
            </div>
          ))}
        </div>
        {crane.comments && (
          <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700">
            <p className="text-xs font-medium text-gray-400 uppercase">Comments</p>
            <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{crane.comments}</p>
          </div>
        )}
      </div>

      {/* Attachments */}
      <div className="mb-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 dark:text-gray-500 mb-3">
          Assigned Equipment
        </p>
      </div>

      <AttachmentTable title="Counterweights" emptyIcon={<ScaleIcon className="w-4 h-4" />}
        items={crane.counterweights || []}
        onDelete={(id, name) => handleDeleteAttachment(id, name, 'counterweight')}
        isOpen={openSections.counterweights}
        onToggle={() => toggleSection('counterweights')}
        columns={[
          { key: 'itemName', label: 'Item Name' },
          { key: 'serialNo', label: 'Serial No.' },
          { key: 'capacity', label: 'Weight' },
          { key: 'weightKg', label: 'Weight (kg)' },
          { key: 'location', label: 'Location' },
          { key: 'condition', label: 'Condition', badge: true },
          { key: 'status', label: 'Status', badge: true },
        ]}
      />

      <AttachmentTable title="Boom Sections" emptyIcon={<BoltIcon className="w-4 h-4" />}
        items={crane.boomSections || []}
        onDelete={(id, name) => handleDeleteAttachment(id, name, 'boom')}
        isOpen={openSections.boomSections}
        onToggle={() => toggleSection('boomSections')}
        columns={[
          { key: 'itemName', label: 'Item Name' },
          { key: 'boomCode', label: 'Boom Code' },
          { key: 'length', label: 'Length' },
          { key: 'weightKg', label: 'Weight (kg)' },
          { key: 'location', label: 'Location' },
          { key: 'condition', label: 'Condition', badge: true },
          { key: 'status', label: 'Status', badge: true },
        ]}
      />

      <AttachmentTable title="Hooks" emptyIcon={<LinkIcon className="w-4 h-4" />}
        items={crane.hooks || []}
        onDelete={(id, name) => handleDeleteAttachment(id, name, 'hook')}
        isOpen={openSections.hooks}
        onToggle={() => toggleSection('hooks')}
        columns={[
          { key: 'itemName', label: 'Item Name' },
          { key: 'hookSerialNo', label: 'Serial No.' },
          { key: 'capacity', label: 'Weight' },
          { key: 'ropeDia', label: 'Rope Dia.' },
          { key: 'weightKg', label: 'Weight (kg)' },
          { key: 'location', label: 'Location' },
          { key: 'status', label: 'Status', badge: true },
        ]}
      />

      {/* Delete Confirmation Dialog */}
      {deleteTarget && (
        <ConfirmDialog
          open={deleteTarget !== null}
          onClose={() => { if (!deleting) { setDeleteTarget(null); setDeleteType(null); }}}
          onConfirm={confirmDelete}
          title="Delete Attachment"
          message={`Are you sure you want to permanently delete "${deleteTarget?.itemName}"? This action cannot be undone.`}
          danger
          loading={deleting}
        />
      )}
    </div>
  );
}
