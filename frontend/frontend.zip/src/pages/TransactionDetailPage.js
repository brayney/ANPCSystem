import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useReactToPrint } from 'react-to-print';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, PrinterIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import { StatusBadge, TableSkeleton } from '../components/common';
import { QRCodeSVG } from 'qrcode.react';
import api from '../utils/api';
import { format } from 'date-fns';

const formatTransactionTime = (timeStr) => {
  if (!timeStr) return null;
  const [hours, minutes] = String(timeStr).split(':');
  if (!hours || !minutes) return String(timeStr);
  const h = parseInt(hours, 10);
  if (Number.isNaN(h)) return String(timeStr);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${minutes} ${ampm}`;
};

const InfoRow = ({ label, value }) => (
  <div className="flex justify-between py-1.5 border-b dark:border-gray-700 last:border-0">
    <span className="text-sm text-gray-500 dark:text-gray-400">{label}</span>
    <span className="text-sm font-medium text-gray-800 dark:text-gray-200 text-right max-w-xs">{value || '—'}</span>
  </div>
);

const getTransactionCranes = (txn) => (
  txn.cranes?.length
    ? txn.cranes
    : [{
        equipmentNo: txn.crane,
        craneModel: txn.craneModel,
        capacity: txn.capacity,
        weightKg: txn.weightKg,
      }]
);

const PrintView = React.forwardRef(({ txn }, ref) => {
  if (!txn) return null;
  const fmt = (d) => d ? format(new Date(d), 'MMMM d, yyyy') : '—';
  const cranes = getTransactionCranes(txn);
  const fmtWithTime = (d) => d ? format(new Date(d), 'MMMM d, yyyy h:mm a') : '—';
  const publicUrl = `${window.location.origin}/public/transactions/${txn._id}`;

  return (
    <div ref={ref} className="p-8 bg-white text-gray-900 font-sans max-w-4xl mx-auto" style={{ width: '210mm', height: '297mm', margin: '0 auto', overflow: 'hidden' }}>
      {/* Header */}
      <div className="flex items-start justify-between border-b-2 border-blue-900 pb-3 mb-4">
        <div className="flex gap-3 items-center">
          <QRCodeSVG value={publicUrl} size={90} />
          <div>
            <img src="/logo.png" alt="NASS Logo" style={{ height: '70px', objectFit: 'contain', marginBottom: '4px' }} />
            <p className="text-sm text-gray-500">EQUIPMENT PULL-OUT / RENTAL FORM</p>
          </div>
        </div>
        <div className="text-right text-sm">
          <p className="font-bold text-blue-900">TXN No: {txn.transactionNo}</p>
          <p className="text-gray-600">{fmt(txn.transactionDate)}</p>
          {txn.transactionTime && <p className="text-gray-600">{formatTransactionTime(txn.transactionTime)}</p>}
          <p className="font-bold mt-1">Status: {txn.status}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-6">
        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Transaction Information</h3>
          <table className="w-full text-sm">
            <tbody>
              {[
                ['Type', txn.type],
                ['Purpose', txn.purpose],
                ['Expected Return', fmt(txn.expectedReturnDate)],
                ...(txn.status === 'Returned' ? [['Actual Return', fmtWithTime(txn.actualReturnDate)]] : []),
              ].map(([l, v]) => (
                <tr key={l}><td className="text-gray-500 pr-2 py-1 text-sm">{l}:</td><td className="font-medium text-sm">{v || '—'}</td></tr>
              ))}
            </tbody>
          </table>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Company Information</h3>
          <table className="w-full text-sm">
            <tbody>
              {[
                ['Company', txn.companyName],
                ['Address', txn.companyAddress],
                ['Contact Person', txn.contactPerson],
                ['Contact Number', txn.contactNumber],
              ].map(([l, v]) => (
                <tr key={l}><td className="text-gray-500 pr-2 py-1 text-sm">{l}:</td><td className="font-medium text-sm">{v || '—'}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Vehicle & Driver - Pickup */}
      <div className="grid grid-cols-2 gap-4 mb-3">
        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Vehicle & Driver (Pickup)</h3>
          <table className="w-full text-sm">
            <tbody>
              {[
                ['Driver', txn.driverName],
                ['Vehicle Type', txn.vehicleType],
                ['Plate No.', txn.vehiclePlateNo],
                ['Pull-Out Location', txn.pullOutLocation],
                ['Delivery Location', txn.deliveryLocation],
              ].map(([l, v]) => (
                <tr key={l}><td className="text-gray-500 pr-2 py-1 text-sm">{l}:</td><td className="font-medium text-sm">{v || '—'}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Vehicle & Driver - Return */}
      {(txn.returnDriverName || txn.returnVehicleType || txn.returnVehiclePlateNo) && (
        <div className="grid grid-cols-2 gap-4 mb-3">
          <div>
            <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Vehicle & Driver (Return)</h3>
            <table className="w-full text-sm">
              <tbody>
                {[
                  ['Return Driver', txn.returnDriverName],
                  ['Return Vehicle Type', txn.returnVehicleType],
                  ['Return Plate No.', txn.returnVehiclePlateNo],
                ].map(([l, v]) => (
                  <tr key={l}><td className="text-gray-500 pr-2 py-1 text-sm">{l}:</td><td className="font-medium text-sm">{v || '—'}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Crane */}
      <div className="mb-4">
        <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Crane Details</h3>
        <table className="w-full text-sm border border-gray-300">
          <thead className="bg-blue-900 text-white">
            <tr>
              <th className="px-3 py-1.5 text-left text-sm">Equipment No.</th>
              <th className="px-3 py-1.5 text-left text-sm">Model</th>
              <th className="px-3 py-1.5 text-left text-sm">Capacity</th>
              <th className="px-3 py-1.5 text-left text-sm">Weight (KG)</th>
              <th className="px-3 py-1.5 text-left text-sm">Expected Return</th>
              <th className="px-3 py-1.5 text-left text-sm">Actual Return</th>
            </tr>
          </thead>
          <tbody>
            {cranes.map((crane, index) => (
              <tr key={crane.craneId || crane.equipmentNo || index} className="border-t border-gray-300">
                <td className="px-3 py-1 font-mono font-bold text-sm">{crane.equipmentNo}</td>
                <td className="px-3 py-1 text-sm">{crane.craneModel || '—'}</td>
                <td className="px-3 py-1 text-sm">{crane.capacity || '—'}</td>
                <td className="px-3 py-1 text-sm">{crane.weightKg || '—'}</td>
                <td className="px-3 py-1 text-sm">{fmt(txn.expectedReturnDate)}</td>
                <td className="px-3 py-1 text-sm">{txn.actualReturnDate ? format(new Date(txn.actualReturnDate), 'MMM d, yyyy h:mm a') : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Attachments */}
      {(txn.counterweights?.length > 0 || txn.boomSections?.length > 0 || txn.hooks?.length > 0) && (
        <div className="mb-3">
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-1 border-b pb-0.5">Included Attachments</h3>
          <table className="w-full text-sm border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-3 py-1 text-left text-sm">Type</th>
                <th className="px-3 py-1 text-left text-sm">Item Name</th>
                <th className="px-3 py-1 text-left text-sm">Code / Serial</th>
                <th className="px-3 py-1 text-left text-sm">Length</th>
                <th className="px-3 py-1 text-left text-sm">Weight (kg)</th>
              </tr>
            </thead>
            <tbody>
              {txn.counterweights?.map((cw, i) => (
                <tr key={i} className="border-t border-gray-200">
                  <td className="px-3 py-1 text-gray-500 text-sm">Counterweight</td>
                  <td className="px-3 py-1 text-sm">{cw.itemName}</td>
                  <td className="px-3 py-1 font-mono text-sm">{cw.serialNo}</td>
                  <td className="px-3 py-1 text-sm">—</td>
                  <td className="px-3 py-1 text-sm">{cw.weightKg || '—'}</td>
                </tr>
              ))}
              {txn.boomSections?.map((bs, i) => (
                <tr key={i} className="border-t border-gray-200">
                  <td className="px-3 py-1 text-gray-500 text-sm">Boom Section</td>
                  <td className="px-3 py-1 text-sm">{bs.itemName}</td>
                  <td className="px-3 py-1 font-mono text-sm">{bs.boomCode}</td>
                  <td className="px-3 py-1 text-sm">{bs.length || '—'}</td>
                  <td className="px-3 py-1 text-sm">{bs.weightKg || '—'}</td>
                </tr>
              ))}
              {txn.hooks?.map((h, i) => (
                <tr key={i} className="border-t border-gray-200">
                  <td className="px-3 py-1 text-gray-500 text-sm">Hook</td>
                  <td className="px-3 py-1 text-sm">{h.itemName}</td>
                  <td className="px-3 py-1 font-mono text-sm">{h.hookSerialNo}</td>
                  <td className="px-3 py-1 text-sm">—</td>
                  <td className="px-3 py-1 text-sm">{h.weightKg || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {txn.remarks && (
        <div className="mb-3 p-3 bg-gray-50 border border-gray-200">
          <p className="text-sm font-semibold text-gray-500 uppercase mb-1">Remarks</p>
          <p className="text-sm">{txn.remarks}</p>
        </div>
      )}

      {/* Signatures */}
      <div className="mt-6 grid grid-cols-3 gap-4">
        {['Released By', 'Received By', 'Authorized By'].map(label => (
          <div key={label} className="text-center">
            <div className="border-b border-gray-400 h-10 mb-2" />
            <p className="text-sm font-semibold text-gray-600 uppercase">{label}</p>
            <p className="text-sm text-gray-400 mt-1">Signature</p>
          </div>
        ))}
      </div>
    </div>
  );
});

export default function TransactionDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const initialTxn = location.state?.txn || null;
  const [txn, setTxn] = useState(initialTxn);
  const [loading, setLoading] = useState(!initialTxn);
  const [returning, setReturning] = useState(false);
  const [returnSameDriver, setReturnSameDriver] = useState(true);
  const [returnForm, setReturnForm] = useState({ returnDriverName: '', returnVehicleType: '', returnVehiclePlateNo: '' });
  const printRef = useRef();

  useEffect(() => {
    if (initialTxn) {
      setTxn(initialTxn);
      setLoading(false);
      return;
    }
    api.get(`/transactions/${id}`)
      .then(r => setTxn(r.data.data))
      .catch(() => { toast.error('Transaction not found'); navigate('/transactions'); })
      .finally(() => setLoading(false));
  }, [id, navigate, initialTxn]);

  const handlePrint = useReactToPrint({ content: () => printRef.current });

const handleReturn = async () => {
     setReturnForm({
       returnDriverName: '',
       returnVehicleType: '',
       returnVehiclePlateNo: '',
     });
     setReturnSameDriver(true);
     setReturning(true);
   };

   const handleReturnConfirm = async () => {
     setReturning(false);
     try {
       const payload = {};
       if (!returnSameDriver) {
         payload.returnDriverName = returnForm.returnDriverName || undefined;
         payload.returnVehicleType = returnForm.returnVehicleType || undefined;
         payload.returnVehiclePlateNo = returnForm.returnVehiclePlateNo || undefined;
       }
       await api.put(`/transactions/${id}/return`, payload);
       toast.success('Marked as returned');
       const { data } = await api.get(`/transactions/${id}`);
       setTxn(data.data);
     } catch { toast.error('Failed'); }
   };

   const handleReturnCancel = () => {
     setReturning(false);
   };

  if (loading) return <TableSkeleton rows={8} cols={8} />;
  if (!txn) return null;
  const cranes = getTransactionCranes(txn);

  const fmt = (d) => d ? format(new Date(d), 'MMMM d, yyyy') : '—';

  return (
    <div>
      {/* Top Bar */}
      <div className="flex items-center gap-4 mb-6 no-print flex-wrap">
        <button onClick={() => navigate('/transactions')} className="btn-secondary flex items-center gap-2">
          <ArrowLeftIcon className="w-4 h-4" /> Back
        </button>
        <div className="flex-1">
          <div>
            <div className="page-header-kicker" />
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-black text-gray-900 dark:text-white font-mono" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.08)' }}>{txn.transactionNo}</h1>
              <StatusBadge status={txn.status} />
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-0.5">{txn.companyName} — {fmt(txn.transactionDate)}</p>
        </div>
        <div className="flex items-center gap-2">
          {txn.status === 'Active' && (
            <button onClick={handleReturn} className="btn-success flex items-center gap-2">
              <CheckCircleIcon className="w-4 h-4" /> Mark Returned
            </button>
          )}
          {returning && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-md mx-4 overflow-hidden">
                <div className="p-4 border-b dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Confirm Return</h3>
                </div>
                <div className="p-4 space-y-4">
                  <p className="text-sm text-gray-700 dark:text-gray-200">
                    Is the driver and vehicle for the return the same as the pickup?
                  </p>
                  <div className="flex gap-3">
                    <button type="button" onClick={() => setReturnSameDriver(true)}
                      className={`flex-1 py-2 rounded-lg text-sm font-semibold ${returnSameDriver ? 'bg-blue-600 text-white' : 'border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
                      Same Driver &amp; Vehicle
                    </button>
                    <button type="button" onClick={() => setReturnSameDriver(false)}
                      className={`flex-1 py-2 rounded-lg text-sm font-semibold ${!returnSameDriver ? 'bg-blue-600 text-white' : 'border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
                      Different Driver &amp; Vehicle
                    </button>
                  </div>
                  {!returnSameDriver && (
                    <div className="space-y-3 pt-2 border-t dark:border-gray-700">
                      <div>
                        <label className="label">Return Driver Name</label>
                        <input type="text" className="input-field"
                          placeholder="Enter return driver name"
                          value={returnForm.returnDriverName}
                          onChange={e => setReturnForm({ ...returnForm, returnDriverName: e.target.value })} />
                      </div>
                      <div>
                        <label className="label">Return Vehicle Type</label>
                        <input type="text" className="input-field"
                          placeholder="Enter return vehicle type"
                          value={returnForm.returnVehicleType}
                          onChange={e => setReturnForm({ ...returnForm, returnVehicleType: e.target.value })} />
                      </div>
                      <div>
                        <label className="label">Return Plate Number</label>
                        <input type="text" className="input-field"
                          placeholder="Enter return plate number"
                          value={returnForm.returnVehiclePlateNo}
                          onChange={e => setReturnForm({ ...returnForm, returnVehiclePlateNo: e.target.value })} />
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-3 border-t dark:border-gray-700 flex justify-end gap-3">
                  <button onClick={handleReturnCancel} className="btn-secondary">Cancel</button>
                  <button onClick={handleReturnConfirm} className="btn-primary">Return</button>
                </div>
              </div>
            </div>
          )}
          <button onClick={handlePrint} className="btn-secondary flex items-center gap-2">
            <PrinterIcon className="w-4 h-4" /> Print
          </button>
        </div>
      </div>

      {/* Screen view */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 no-print mb-6">
        {/* Left */}
        <div className="card">
          <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Transaction Details</h3>
          <InfoRow label="Transaction No." value={txn.transactionNo} />
          <InfoRow label="Type" value={txn.type} />
          <InfoRow label="Status" value={<StatusBadge status={txn.status} />} />
          <InfoRow label="Date" value={fmt(txn.transactionDate)} />
          <InfoRow label="Time" value={formatTransactionTime(txn.transactionTime)} />
          <InfoRow label="Expected Return" value={fmt(txn.expectedReturnDate)} />
          <InfoRow label="Actual Return" value={fmt(txn.actualReturnDate)} />
          <InfoRow label="Purpose" value={txn.purpose} />
          <InfoRow label="Remarks" value={txn.remarks} />
        </div>

        {/* Right */}
        <div className="space-y-4">
          <div className="card">
            <h3 className="font-semibold text-gray-800 dark:text-white mb-3">Company & Logistics</h3>
            <InfoRow label="Company" value={txn.companyName} />
            <InfoRow label="Address" value={txn.companyAddress} />
            <InfoRow label="Contact Person" value={txn.contactPerson} />
            <InfoRow label="Contact Number" value={txn.contactNumber} />
            <InfoRow label="Pull-Out Location" value={txn.pullOutLocation} />
            <InfoRow label="Delivery Location" value={txn.deliveryLocation} />
            <InfoRow label="Driver" value={txn.driverName} />
            <InfoRow label="Vehicle" value={txn.vehicleType} />
            <InfoRow label="Plate No." value={txn.vehiclePlateNo} />
          </div>
        </div>
      </div>

      {/* Crane & Attachments */}
      <div className="card no-print mb-6">
        <h3 className="font-semibold text-gray-800 dark:text-white mb-4">Equipment</h3>
        <div className="mb-4">
          <p className="text-xs font-semibold text-gray-400 uppercase mb-2">Cranes ({cranes.length})</p>
          <div className="flex flex-wrap gap-2">
            {cranes.map((crane, index) => (
              <span key={crane.craneId || crane.equipmentNo || index} className="px-2 py-1 bg-blue-50 dark:bg-blue-900/20 text-xs">
                <span className="font-mono text-blue-700 dark:text-blue-400 font-bold">{crane.equipmentNo}</span>
                <span className="text-gray-500 ml-1">{crane.craneModel}</span>
              </span>
            ))}
          </div>
        </div>
        {txn.counterweights?.length > 0 && (
          <div className="mb-3">
            <p className="text-xs font-semibold text-gray-400 uppercase mb-2">Counterweights ({txn.counterweights.length})</p>
            <div className="flex flex-wrap gap-2">
              {txn.counterweights.map(cw => (
                <span key={cw._id} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs">{cw.itemName}</span>
              ))}
            </div>
          </div>
        )}
        {txn.boomSections?.length > 0 && (
          <div className="mb-3">
            <p className="text-xs font-semibold text-gray-400 uppercase mb-2">Boom Sections ({txn.boomSections.length})</p>
            <div className="flex flex-wrap gap-2">
              {txn.boomSections.map(bs => (
                <span key={bs._id} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs">{bs.itemName}</span>
              ))}
            </div>
          </div>
        )}
        {txn.hooks?.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase mb-2">Hooks ({txn.hooks.length})</p>
            <div className="flex flex-wrap gap-2">
              {txn.hooks.map(h => (
                <span key={h._id} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs">{h.itemName}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Hidden Print View */}
      <div className="hidden print-only">
        <PrintView ref={printRef} txn={txn} />
      </div>
    </div>
  );
}
