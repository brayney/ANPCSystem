import React from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router-dom';
import { EllipsisVerticalIcon, XMarkIcon, InboxIcon } from '@heroicons/react/24/outline';

// ── Skeleton loaders ────────────────────────────────────────────────────────
export const Skeleton = ({ width = '100%', height = '14px', radius = '6px', style }) => (
  <span
    className="skeleton"
    aria-hidden="true"
    style={{ display: 'block', width, height, borderRadius: radius, ...style }}
  />
);

export const StatCardSkeleton = () => (
  <div className="card" style={{ padding: '16px 18px', minHeight: '132px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' }}>
      <div style={{ flex: 1 }}>
        <Skeleton width="55%" height="11px" />
        <div style={{ height: '14px' }} />
        <Skeleton width="40%" height="28px" />
      </div>
      <Skeleton width="40px" height="40px" radius="8px" />
    </div>
    <Skeleton height="3px" style={{ marginTop: '16px' }} />
  </div>
);

export const TableSkeleton = ({ rows = 8, cols = 6 }) => (
  <div className="app-scrollbar" style={{ overflowX: 'auto' }}>
    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r} style={{ borderBottom: '1px solid var(--border-muted)' }}>
            {Array.from({ length: cols }).map((_, c) => (
              <td key={c} className="table-cell">
                <Skeleton width={c === 0 ? '70%' : `${40 + ((r + c) % 4) * 12}%`} height="12px" />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export const CardSkeleton = ({ height = '220px' }) => (
  <div className="card" style={{ padding: '20px', minHeight: height }}>
    <Skeleton width="40%" height="14px" />
    <div style={{ height: '20px' }} />
    <Skeleton width="100%" height={`${Math.max(40, (height - 80))}px`} radius="8px" />
  </div>
);

// ── Status Badge ──────────────────────────────────────────────────────────────
export const StatusBadge = ({ status }) => {
  const styles = {
    'Available':          'bg-[var(--success-bg)] text-[var(--success)] border-[color:var(--success)]',
    'On Hire':            'bg-[var(--accent-subtle)] text-[var(--accent-text)] border-[color:var(--accent)]',
    'Standby':            'bg-[var(--warning-bg)] text-[var(--warning)] border-[color:var(--warning)]',
    'Under Maintenance':  'bg-[var(--orange-bg)] text-[var(--orange)] border-[color:var(--orange)]',
    'Out of Yard':        'bg-[var(--danger-bg)] text-[var(--danger)] border-[color:var(--danger)]',
    'Reserved':           'bg-[var(--purple-bg)] text-[var(--purple)] border-[color:var(--purple)]',
    'Active':             'bg-[var(--accent-subtle)] text-[var(--accent-text)] border-[color:var(--accent)]',
    'Returned':           'bg-[var(--success-bg)] text-[var(--success)] border-[color:var(--success)]',
    'Overdue':            'bg-[var(--danger-bg)] text-[var(--danger)] border-[color:var(--danger)]',
    'Cancelled':          'bg-[var(--surface-3)] text-[var(--text-secondary)] border-[color:var(--border)]',
    'Allocated':          'bg-[var(--purple-bg)] text-[var(--purple)] border-[color:var(--purple)]',
    'In Use':             'bg-[var(--accent-subtle)] text-[var(--accent-text)] border-[color:var(--accent)]',
    'OK':                 'bg-[var(--success-bg)] text-[var(--success)] border-[color:var(--success)]',
    'Ok':                 'bg-[var(--success-bg)] text-[var(--success)] border-[color:var(--success)]',
    'NOT OK':             'bg-[var(--danger-bg)] text-[var(--danger)] border-[color:var(--danger)]',
    'For Repair':         'bg-[var(--orange-bg)] text-[var(--orange)] border-[color:var(--orange)]',
  };
  const dotColors = {
    'Available': '#1a7f37', 'On Hire': '#1f6feb', 'Active': '#1f6feb',
    'Returned': '#1a7f37', 'Overdue': '#cf222e', 'Out of Yard': '#cf222e',
    'Under Maintenance': '#bc4c00', 'For Repair': '#bc4c00',
    'Standby': '#9a6700', 'Reserved': '#6e40c9', 'Allocated': '#6e40c9',
    'In Use': '#1f6feb', 'OK': '#1a7f37', 'Ok': '#1a7f37', 'NOT OK': '#cf222e',
  };

  return (
    <span className={`badge ${styles[status] || 'bg-[var(--surface-3)] text-[var(--text-secondary)] border-[color:var(--border)]'}`}
      style={{ borderWidth: '1px', borderStyle: 'solid', borderColor: 'currentColor', opacity: 1 }}>
      <span className="inline-block w-1.5 h-1.5 rounded-full mr-1.5 flex-shrink-0"
        style={{ backgroundColor: dotColors[status] || '#9198a1' }} />
      {status || 'Unknown'}
    </span>
  );
};

// ── Spinner ───────────────────────────────────────────────────────────────────
export const Spinner = ({ size = 'md' }) => {
  const s = size === 'sm' ? '14px' : size === 'lg' ? '36px' : '20px';
  return (
    <div style={{
      display: 'block',
      width: s,
      height: s,
      flexShrink: 0,
      margin: '0 auto',
      borderRadius: '50%',
      border: `2px solid var(--border)`,
      borderTopColor: 'var(--accent)',
      animation: 'spin 0.7s linear infinite',
      boxSizing: 'border-box',
    }} />
  );
};

// ── Page Header ───────────────────────────────────────────────────────────────
export const PageHeader = ({ title, subtitle, actions }) => (
  <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
    <div style={{ minWidth: 0 }}>
      <div className="page-header-kicker" />
      <h1 style={{
        fontFamily: 'var(--font-sans)',
        fontSize: 'clamp(22px, 3vw, 30px)',
        fontWeight: 900,
        color: 'var(--text-primary)',
        lineHeight: 1.1,
        margin: 0,
        letterSpacing: 0,
        textShadow: '0 1px 2px rgba(0,0,0,0.08)',
      }}>{title}</h1>
      {subtitle && (
        <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginTop: '6px', maxWidth: '720px' }}>
          {subtitle}
        </p>
      )}
    </div>
    {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
  </div>
);

export const ActionMenu = ({ actions }) => {
  const [open, setOpen] = React.useState(false);
  const menuRef = React.useRef(null);
  const visibleActions = actions.filter(Boolean);

  React.useEffect(() => {
    if (!open) return undefined;
    const closeOnOutsideClick = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) setOpen(false);
    };
    document.addEventListener('mousedown', closeOnOutsideClick);
    return () => document.removeEventListener('mousedown', closeOnOutsideClick);
  }, [open]);

  if (visibleActions.length === 0) {
    return <span style={{ color: 'var(--text-muted)', fontSize: '12px' }}>-</span>;
  }

  const menuItemStyle = (danger) => ({
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 10px',
    border: 'none',
    background: 'transparent',
    color: danger ? 'var(--danger)' : 'var(--text-secondary)',
    fontSize: '12px',
    fontWeight: 600,
    textAlign: 'left',
    textDecoration: 'none',
    cursor: 'pointer',
  });

  const renderAction = (action) => {
    const Icon = action.icon;
    const content = (
      <>
        {Icon && <Icon style={{ width: '13px', height: '13px' }} />}
        {action.label}
      </>
    );

    if (action.to) {
      return (
        <Link key={action.label} to={action.to} style={menuItemStyle(action.danger)} onClick={() => setOpen(false)}>
          {content}
        </Link>
      );
    }

    return (
      <button key={action.label} type="button" style={menuItemStyle(action.danger)} onClick={() => { setOpen(false); action.onClick(); }}>
        {content}
      </button>
    );
  };

  return (
    <div ref={menuRef} style={{ position: 'relative', display: 'inline-flex' }}>
      <button
        type="button"
        title="Actions"
        onClick={() => setOpen(prev => !prev)}
        style={{
          width: '28px',
          height: '28px',
          borderRadius: '6px',
          border: '1px solid var(--border)',
          background: open ? 'var(--surface-3)' : 'var(--surface-2)',
          color: 'var(--text-secondary)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
        }}
      >
        <EllipsisVerticalIcon style={{ width: '15px', height: '15px' }} />
      </button>
      {open && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            top: 'calc(100% + 4px)',
            minWidth: '128px',
            padding: '4px',
            border: '1px solid var(--border)',
            borderRadius: '8px',
            background: 'var(--surface)',
            boxShadow: 'var(--shadow-lg)',
            zIndex: 30,
          }}
        >
          {visibleActions.map(renderAction)}
        </div>
      )}
    </div>
  );
};

// ── Stat Card ─────────────────────────────────────────────────────────────────
export const StatCard = ({ title, value, icon: Icon, color = 'blue', subtitle }) => {
  const accents = {
    blue:   { bg: 'var(--accent-subtle)',  icon: 'var(--accent)',   ring: 'rgba(31,107,235,0.15)' },
    green:  { bg: 'var(--success-bg)',     icon: 'var(--success)',  ring: 'rgba(26,127,55,0.15)' },
    yellow: { bg: 'var(--warning-bg)',     icon: 'var(--warning)',  ring: 'rgba(154,103,0,0.15)' },
    red:    { bg: 'var(--danger-bg)',      icon: 'var(--danger)',   ring: 'rgba(207,34,46,0.15)' },
    purple: { bg: 'var(--purple-bg)',      icon: 'var(--purple)',   ring: 'rgba(110,64,201,0.15)' },
    indigo: { bg: 'var(--purple-bg)',      icon: 'var(--purple)',   ring: 'rgba(110,64,201,0.15)' },
    orange: { bg: 'var(--orange-bg)',      icon: 'var(--orange)',   ring: 'rgba(188,76,0,0.15)' },
    teal:   { bg: 'var(--teal-bg)',        icon: 'var(--teal)',     ring: 'rgba(14,122,110,0.15)' },
  };
  const a = accents[color] || accents.blue;

  return (
    <div className="card animate-fade-in" style={{ padding: '16px 18px', minHeight: '132px' }}>
      <div className="flex items-start justify-between gap-3">
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
            {title}
          </p>
          <p style={{ fontSize: '30px', fontFamily: 'var(--font-sans)', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1, letterSpacing: 0 }}>
            {value ?? '-'}
          </p>
          {subtitle && <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '7px', lineHeight: 1.35 }}>{subtitle}</p>}
        </div>
        {Icon && (
          <div style={{
            width: '40px', height: '40px', borderRadius: '8px',
            background: a.bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, boxShadow: `0 0 0 4px ${a.ring}`,
          }}>
            <Icon style={{ width: '18px', height: '18px', color: a.icon }} />
          </div>
        )}
      </div>
      <div style={{ height: '3px', marginTop: '16px', borderRadius: '2px', background: a.bg, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: '60%', background: a.icon, borderRadius: '2px', opacity: 0.7 }} />
      </div>
    </div>
  );
};

// ── Modal ─────────────────────────────────────────────────────────────────────
export const Modal = ({ open, onClose, title, children, size = 'md' }) => {
  const dialogRef = React.useRef(null);

  React.useEffect(() => {
    if (!open) return undefined;

    const rootElement = document.body;
    const previousOverflow = rootElement.style.overflow;
    const previousOverflowY = rootElement.style.overflowY;
    const previousPaddingRight = rootElement.style.paddingRight;
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

    if (scrollbarWidth > 0) {
      rootElement.style.paddingRight = `${(parseFloat(previousPaddingRight || '0') || 0) + scrollbarWidth}px`;
    }
    rootElement.style.overflow = 'hidden';
    rootElement.style.overflowY = 'hidden';

    const onKeyDown = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose?.();
        return;
      }
      if (e.key === 'Tab') {
        const focusables = dialogRef.current?.querySelectorAll(
          'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        if (!focusables || focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault(); last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault(); first.focus();
        }
      }
    };

    document.addEventListener('keydown', onKeyDown);
    // Move focus into the dialog for screen-reader / keyboard users
    const focusTimer = setTimeout(() => {
      const target = dialogRef.current?.querySelector('input, button, [tabindex], h2');
      target?.focus?.();
    }, 30);

    return () => {
      document.removeEventListener('keydown', onKeyDown);
      clearTimeout(focusTimer);
      rootElement.style.overflow = previousOverflow;
      rootElement.style.overflowY = previousOverflowY;
      rootElement.style.paddingRight = previousPaddingRight;
    };
  }, [open, onClose]);

  if (!open) return null;
  const maxWidths = { sm: '440px', md: '540px', lg: '720px', xl: '900px', full: '1100px' };

  return ReactDOM.createPortal(
    <div className="no-print" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 10050, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', padding: '24px 16px 16px' }}>
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(1,4,9,0.45)', backdropFilter: 'blur(2px)' }} onClick={onClose} />
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-label={title} className="animate-scale-in" style={{
        position: 'relative',
        background: 'var(--surface)',
        border: '1px solid var(--border)', borderRadius: '12px',
        boxShadow: 'var(--shadow-lg)', width: '100%',
        maxWidth: maxWidths[size], maxHeight: '90vh', display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <h2 style={{ fontFamily: 'var(--font-sans)', fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>{title}</h2>
          <button onClick={onClose} title="Close" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '28px', height: '28px', borderRadius: '6px', border: '1px solid var(--border)', background: 'var(--surface-2)', cursor: 'pointer', color: 'var(--text-secondary)', transition: 'background 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-3)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--surface-2)'}>
            <XMarkIcon style={{ width: '14px', height: '14px' }} />
          </button>
        </div>
        <div style={{ padding: '20px', overflowY: 'auto', flex: 1 }}>{children}</div>
      </div>
    </div>
  , document.body);
};

// ── Pagination ────────────────────────────────────────────────────────────────
export const Pagination = ({ page, pages, total, onPage }) => {
  if (pages <= 1) return null;
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '12px 16px', borderTop: '1px solid var(--border-muted)', minHeight: '53px' }}>
      <span style={{ position: 'absolute', left: '16px', fontSize: '12px', color: 'var(--text-secondary)' }}>{total} records</span>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
        <button onClick={() => onPage(page - 1)} disabled={page === 1} className="btn-secondary" style={{ padding: '4px 10px', fontSize: '12px' }}>Prev</button>
        <span style={{ fontSize: '12px', color: 'var(--text-secondary)', padding: '0 8px', fontWeight: 600 }}>{page} / {pages}</span>
        <button onClick={() => onPage(page + 1)} disabled={page === pages} className="btn-secondary" style={{ padding: '4px 10px', fontSize: '12px' }}>Next</button>
      </div>
    </div>
  );
};

// ── Empty State ───────────────────────────────────────────────────────────────
export const EmptyState = ({ message = 'No records found', hint, icon, action }) => (
  <div style={{ textAlign: 'center', padding: '56px 24px', animation: 'fadeIn 0.3s ease both' }}>
    <div style={{ width: '56px', height: '56px', borderRadius: '14px', margin: '0 auto 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      {icon || <InboxIcon style={{ width: '26px', height: '26px' }} />}
    </div>
    <p style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>{message}</p>
    {hint && <p style={{ fontSize: '12px', color: 'var(--text-secondary)', margin: '6px 0 0', maxWidth: '360px', marginLeft: 'auto', marginRight: 'auto' }}>{hint}</p>}
    {action && <div style={{ marginTop: '18px', display: 'flex', justifyContent: 'center' }}>{action}</div>}
  </div>
);

// ── Confirm Dialog ────────────────────────────────────────────────────────────
export const ConfirmDialog = ({ open, onClose, onConfirm, title, message, danger, loading, children }) => (
  <Modal open={open} onClose={onClose} title={title} size="sm">
    <p style={{ color: 'var(--text-secondary)', fontSize: '14px', marginBottom: '20px', lineHeight: 1.6 }}>{message}</p>
    {children}
    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '20px' }}>
      <button onClick={onClose} className="btn-secondary" disabled={loading}>Cancel</button>
      <button onClick={onConfirm} disabled={loading} className={danger ? 'btn-danger' : 'btn-primary'} style={{ opacity: loading ? 0.6 : 1, cursor: loading ? 'not-allowed' : 'pointer' }}>
        {loading ? 'Deleting...' : 'Confirm'}
      </button>
    </div>
  </Modal>
);
