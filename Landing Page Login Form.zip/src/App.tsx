import { useState, useEffect } from 'react'

/* ── Icons ── */
const LogoMark = () => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    <rect width="32" height="32" rx="8" fill="url(#lg)" />
    <path d="M16 6l-8 14h6v6l8-14h-6V6z" fill="white" />
    <defs>
      <linearGradient id="lg" x1="0" y1="0" x2="32" y2="32">
        <stop stopColor="#7c6ef7" />
        <stop offset="1" stopColor="#4f46e5" />
      </linearGradient>
    </defs>
  </svg>
)

const EyeIcon = ({ open }: { open: boolean }) => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    {open ? (
      <>
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ) : (
      <>
        <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
        <line x1="1" y1="1" x2="23" y2="23" />
      </>
    )}
  </svg>
)

const ChevronLeft = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M15 18l-6-6 6-6" />
  </svg>
)

const ChevronRight = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M9 18l6-6-6-6" />
  </svg>
)

const ShieldIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
)



const features = [
  'Track every job, asset, and workflow in real time',
  'AI-powered analytics and anomaly detection',
  'Role-based access with end-to-end encryption',
]

/* ─────────────────────────────────────── */

export default function App() {
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 60)
    return () => clearTimeout(t)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => setLoading(false), 2200)
  }

  return (
    <div
      style={{
        position: 'relative',
        width: '100vw',
        height: '100vh',
        overflow: 'hidden',
        fontFamily: "'Inter', system-ui, sans-serif",
      }}
    >
      {/* ── Background image ── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'url(https://images.unsplash.com/photo-1659952801569-a8aebf1eef22?w=1800&h=900&fit=crop&auto=format)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'brightness(0.45) saturate(0.8)',
          transform: open ? 'scale(1.03)' : 'scale(1)',
          transition: 'transform 0.9s cubic-bezier(0.16,1,0.3,1), filter 0.9s ease',
          willChange: 'transform',
        }}
      />

      {/* ── Gradient overlays ── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'linear-gradient(105deg, rgba(7,9,26,0.82) 0%, rgba(7,9,26,0.55) 55%, rgba(7,9,26,0.15) 100%)',
          pointerEvents: 'none',
        }}
      />
      {/* Right edge vignette — deepens when sidebar open */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: open
            ? 'linear-gradient(to left, rgba(7,9,26,0.9) 0%, transparent 55%)'
            : 'linear-gradient(to left, rgba(7,9,26,0.4) 0%, transparent 60%)',
          transition: 'background 0.8s ease',
          pointerEvents: 'none',
        }}
      />

      {/* ── Noise grain ── */}
      <div className="noise" style={{ position: 'absolute', inset: 0, opacity: 0.025, pointerEvents: 'none', backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")", backgroundSize: '128px 128px' }} />

      {/* ══════════════ LEFT — hero content ══════════════ */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          padding: 'clamp(1.75rem, 4vw, 3.5rem)',
          pointerEvents: 'none',
        }}
      >
        {/* Logo */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            opacity: mounted ? 1 : 0,
            transform: mounted ? 'translateY(0)' : 'translateY(-16px)',
            transition: 'opacity 0.6s ease 0.05s, transform 0.6s cubic-bezier(0.16,1,0.3,1) 0.05s',
            pointerEvents: 'auto',
          }}
        >
          <LogoMark />
          <div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.125rem', fontWeight: 600, color: '#e8eaf6', letterSpacing: '-0.01em', lineHeight: 1 }}>
              Luminary
            </div>
            <div style={{ fontSize: '0.625rem', letterSpacing: '0.14em', color: 'rgba(232,234,246,0.4)', textTransform: 'uppercase', marginTop: 2 }}>
              Command Platform
            </div>
          </div>
        </div>

        {/* Hero copy — bottom-left */}
        <div style={{ maxWidth: 560 }}>
          {/* badge */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '5px 14px',
              background: 'rgba(124,110,247,0.15)',
              border: '1px solid rgba(124,110,247,0.3)',
              borderRadius: 40,
              marginBottom: '1.25rem',
              opacity: mounted ? 1 : 0,
              transform: mounted ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.65s ease 0.2s, transform 0.65s cubic-bezier(0.16,1,0.3,1) 0.2s',
            }}
          >
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#a594f9', display: 'inline-block', boxShadow: '0 0 6px #a594f9' }} />
            <span style={{ fontSize: '0.6875rem', letterSpacing: '0.1em', color: '#c4b5fd', fontWeight: 600, textTransform: 'uppercase' }}>
              Now live — v3.0 Release
            </span>
          </div>

          <h1
            style={{
              fontFamily: "'Fraunces', serif",
              fontSize: 'clamp(2.5rem, 5.5vw, 4.25rem)',
              fontWeight: 700,
              lineHeight: 1.05,
              letterSpacing: '-0.03em',
              color: '#f0f2ff',
              margin: '0 0 1rem',
              opacity: mounted ? 1 : 0,
              transform: mounted ? 'translateY(0)' : 'translateY(24px)',
              transition: 'opacity 0.7s ease 0.32s, transform 0.7s cubic-bezier(0.16,1,0.3,1) 0.32s',
            }}
          >
            Yard Operations
            <br />
            <em
              style={{
                fontStyle: 'italic',
                fontWeight: 300,
                background: 'linear-gradient(90deg, #a594f9 0%, #e9b96e 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Command Center
            </em>
          </h1>

          <p
            style={{
              fontSize: 'clamp(0.9375rem, 1.5vw, 1.0625rem)',
              lineHeight: 1.7,
              color: 'rgba(240,242,255,0.55)',
              fontWeight: 300,
              margin: '0 0 1.75rem',
              opacity: mounted ? 1 : 0,
              transform: mounted ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.65s ease 0.44s, transform 0.65s cubic-bezier(0.16,1,0.3,1) 0.44s',
            }}
          >
            Manage assets, track job orders, and command every<br />
            workflow — from one unified operations platform.
          </p>

          {/* feature list */}
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 10,
              marginBottom: '2.5rem',
              opacity: mounted ? 1 : 0,
              transform: mounted ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.65s ease 0.54s, transform 0.65s cubic-bezier(0.16,1,0.3,1) 0.54s',
            }}
          >
            {features.map((f) => (
              <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'rgba(240,242,255,0.65)', fontSize: '0.9rem' }}>
                <span style={{ width: 18, height: 18, borderRadius: '50%', background: 'rgba(124,110,247,0.2)', border: '1px solid rgba(124,110,247,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5l2 2 4-4" stroke="#a594f9" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </span>
                {f}
              </div>
            ))}
          </div>

        </div>
      </div>

      {/* ══════════════ SIDEBAR TOGGLE TAB ══════════════ */}
      <button
        onClick={() => setOpen(!open)}
        aria-label={open ? 'Close sign-in panel' : 'Open sign-in panel'}
        style={{
          position: 'fixed',
          right: open ? 400 : 0,
          top: '50%',
          transform: 'translateY(-50%)',
          zIndex: 50,
          width: 40,
          height: 88,
          background: 'rgba(14,18,48,0.85)',
          border: '1px solid rgba(124,110,247,0.3)',
          borderRight: open ? '1px solid rgba(124,110,247,0.3)' : 'none',
          borderRadius: open ? '12px 0 0 12px' : '12px 0 0 12px',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 6,
          color: 'rgba(232,234,246,0.7)',
          backdropFilter: 'blur(16px)',
          boxShadow: '-4px 0 24px rgba(0,0,0,0.4)',
          transition: 'right 0.5s cubic-bezier(0.16,1,0.3,1), background 0.2s ease, color 0.2s ease',
          outline: 'none',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = 'rgba(124,110,247,0.25)'
          e.currentTarget.style.color = '#fff'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'rgba(14,18,48,0.85)'
          e.currentTarget.style.color = 'rgba(232,234,246,0.7)'
        }}
      >
        {open ? <ChevronRight /> : <ChevronLeft />}
        <span
          style={{
            fontSize: '0.6rem',
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            fontWeight: 600,
            writingMode: 'vertical-rl',
            textOrientation: 'mixed',
            transform: 'rotate(180deg)',
            lineHeight: 1,
            marginTop: 2,
          }}
        >
          {open ? 'Close' : 'Sign in'}
        </span>
      </button>

      {/* ══════════════ RIGHT — login sidebar ══════════════ */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          right: open ? 0 : -420,
          width: 400,
          height: '100vh',
          background: 'rgba(7,9,26,0.88)',
          backdropFilter: 'blur(28px)',
          borderLeft: '1px solid rgba(124,110,247,0.18)',
          boxShadow: '-24px 0 80px rgba(0,0,0,0.6)',
          zIndex: 40,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          padding: '2.5rem 2.25rem',
          transition: 'right 0.55s cubic-bezier(0.16,1,0.3,1)',
          overflowY: 'auto',
        }}
      >
        {/* Top accent line */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: '15%',
            right: '15%',
            height: 1,
            background: 'linear-gradient(90deg, transparent, rgba(124,110,247,0.6), transparent)',
          }}
        />

        {/* Panel header */}
        <div style={{ marginBottom: '2rem', opacity: open ? 1 : 0, transform: open ? 'translateX(0)' : 'translateX(24px)', transition: 'opacity 0.5s ease 0.15s, transform 0.5s cubic-bezier(0.16,1,0.3,1) 0.15s' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '0.5rem' }}>
            <LogoMark />
            <span style={{ fontFamily: "'Fraunces', serif", fontSize: '1rem', fontWeight: 600, color: '#e8eaf6' }}>Luminary</span>
          </div>
          <h2
            style={{
              fontFamily: "'Fraunces', serif",
              fontSize: '1.75rem',
              fontWeight: 600,
              letterSpacing: '-0.02em',
              color: '#f0f2ff',
              margin: '1.25rem 0 0.375rem',
            }}
          >
            Welcome back
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'rgba(232,234,246,0.4)', margin: 0, fontWeight: 300 }}>
            Sign in to your command center.
          </p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          style={{
            opacity: open ? 1 : 0,
            transform: open ? 'translateX(0)' : 'translateX(24px)',
            transition: 'opacity 0.5s ease 0.3s, transform 0.5s cubic-bezier(0.16,1,0.3,1) 0.3s',
          }}
        >
          {/* Email */}
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: 'rgba(232,234,246,0.45)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
              Email Address
            </label>
            <input
              className="login-input"
              type="email"
              placeholder="admin@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>

          {/* Password */}
          <div style={{ marginBottom: '0.75rem' }}>
            <div style={{ marginBottom: '0.5rem' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'rgba(232,234,246,0.45)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                Password
              </label>
            </div>
            <div style={{ position: 'relative' }}>
              <input
                className="login-input"
                type={showPw ? 'text' : 'password'}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{ paddingRight: '3rem' }}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                style={{
                  position: 'absolute',
                  right: 14,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  color: 'rgba(255,255,255,0.28)',
                  cursor: 'pointer',
                  padding: 4,
                  display: 'flex',
                  alignItems: 'center',
                  transition: 'color 0.15s ease',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.65)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.28)')}
              >
                <EyeIcon open={showPw} />
              </button>
            </div>
          </div>

          {/* Remember */}
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: '0.875rem', color: 'rgba(232,234,246,0.45)' }}>
              <input type="checkbox" style={{ width: 15, height: 15, accentColor: '#7c6ef7', cursor: 'pointer' }} />
              Keep me signed in
            </label>
          </div>

          {/* Submit */}
          <button className="login-btn" type="submit" disabled={loading}>
            {loading ? (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" style={{ animation: 'spin 0.8s linear infinite' }}>
                  <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
                  <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
                </svg>
                Authenticating…
              </span>
            ) : (
              'Sign in to Command Center'
            )}
          </button>
        </form>

        {/* Footer */}
        <div
          style={{
            marginTop: '1.5rem',
            textAlign: 'center',
            opacity: open ? 1 : 0,
            transition: 'opacity 0.5s ease 0.4s',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: '0.75rem', color: 'rgba(232,234,246,0.28)', marginBottom: '1rem' }}>
            <ShieldIcon />
            256-bit encrypted · SOC 2 certified
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'rgba(232,234,246,0.3)', margin: 0 }}>
            No account?{' '}
            <a
              href="#"
              style={{ color: '#a594f9', textDecoration: 'none', fontWeight: 500 }}
              onMouseEnter={(e) => (e.currentTarget.style.color = '#c4b5fd')}
              onMouseLeave={(e) => (e.currentTarget.style.color = '#a594f9')}
            >
              Request access →
            </a>
          </p>
        </div>

        {/* Bottom accent line */}
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: '15%',
            right: '15%',
            height: 1,
            background: 'linear-gradient(90deg, transparent, rgba(124,110,247,0.4), transparent)',
          }}
        />
      </div>
    </div>
  )
}
