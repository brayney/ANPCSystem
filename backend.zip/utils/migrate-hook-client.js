const mongoose = require('mongoose');
require('dotenv').config();

const Hook = require('../models/Hook');

async function migrateHookClient() {
  try {
    console.log('🔄 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    console.log('🔄 Updating all hooks client to "-"...');
    const result = await Hook.updateMany(
      { $or: [{ client: null }, { client: '' }, { client: { $exists: false } }] },
      { $set: { client: '-' } }
    );
    console.log(`✅ Updated ${result.modifiedCount} hooks`);
    console.log(`📊 Matched ${result.matchedCount} total hooks`);

    await mongoose.connection.close();
    console.log('✅ Migration complete');
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
}

migrateHookClient();
